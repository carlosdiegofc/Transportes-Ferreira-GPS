package uy.transportesferreira.gps
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity: AppCompatActivity() {
 private val permissions = 10
 override fun onCreate(b: Bundle?) {
  super.onCreate(b); setContentView(R.layout.activity_main)
  val email=findViewById<EditText>(R.id.email); val pass=findViewById<EditText>(R.id.password); val name=findViewById<EditText>(R.id.driverName); val vehicle=findViewById<EditText>(R.id.vehicle); val status=findViewById<TextView>(R.id.status)
  val prefs=getSharedPreferences("gps",MODE_PRIVATE); email.setText(prefs.getString("email","")); name.setText(prefs.getString("driver","")); vehicle.setText(prefs.getString("vehicle",""))
  findViewById<Button>(R.id.start).setOnClickListener {
   if(email.text.isBlank()||pass.text.isBlank()||name.text.isBlank()||vehicle.text.isBlank()){ Toast.makeText(this,"Completá email, contraseña, chofer y camión",Toast.LENGTH_LONG).show(); return@setOnClickListener }
   val req=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION); if(Build.VERSION.SDK_INT>=33) req.add(Manifest.permission.POST_NOTIFICATIONS)
   if(req.any{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED}){ActivityCompat.requestPermissions(this,req.toTypedArray(),permissions);return@setOnClickListener}
   prefs.edit().putString("email",email.text.toString()).putString("driver",name.text.toString()).putString("vehicle",vehicle.text.toString()).apply()
   val i=Intent(this,GpsService::class.java).putExtra("email",email.text.toString()).putExtra("password",pass.text.toString()).putExtra("driver",name.text.toString()).putExtra("vehicle",vehicle.text.toString())
   ContextCompat.startForegroundService(this,i); status.text="GPS activo · podés bloquear el teléfono"
  }
  findViewById<Button>(R.id.stop).setOnClickListener { stopService(Intent(this,GpsService::class.java)); status.text="GPS detenido" }
 }
}
