package uy.transportesferreira.gps

import android.app.*
import android.content.Intent
import android.location.Location
import android.os.IBinder
import com.google.android.gms.location.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class GpsService: Service() {
 companion object { const val ACTION_STARTED="uy.transportesferreira.gps.TRACKING_STARTED"; const val ACTION_ERROR="uy.transportesferreira.gps.TRACKING_ERROR" }
 private lateinit var fused:FusedLocationProviderClient
 private var token:String?=null; private var uid:String?=null
 private var driver=""; private var vehicle=""; private var email=""; private var password=""
 private var callback: LocationCallback?=null
 override fun onBind(i:Intent?):IBinder?=null
 override fun onCreate(){ super.onCreate(); fused=LocationServices.getFusedLocationProviderClient(this); channel() }
 override fun onStartCommand(i:Intent?, flags:Int, id:Int):Int {
  driver=i?.getStringExtra("driver")?:""; vehicle=i?.getStringExtra("vehicle")?:""
  email=i?.getStringExtra("email")?:""; password=i?.getStringExtra("password")?:""
  startForeground(7, Notification.Builder(this,"gps").setContentTitle("Transportes Ferreira GPS").setContentText("Seguimiento activo · $vehicle").setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build())
  thread { if(login()) { if(startSession()) { startGps(); sendBroadcast(Intent(ACTION_STARTED).setPackage(packageName)) } else { sendBroadcast(Intent(ACTION_ERROR).setPackage(packageName).putExtra("message","Supabase rechazó la creación del viaje")); stopSelf() } } else { sendBroadcast(Intent(ACTION_ERROR).setPackage(packageName).putExtra("message","login o conexión con Supabase")); stopSelf() } }
  return START_REDELIVER_INTENT
 }
 private fun login():Boolean = try {
  val c=conn("/auth/v1/token?grant_type=password","POST",false); c.setRequestProperty("Content-Type","application/json")
  c.outputStream.use{it.write(JSONObject().put("email",email).put("password",password).toString().toByteArray())}
  if(c.responseCode !in 200..299) false else { val j=JSONObject(c.inputStream.bufferedReader().readText()); token=j.getString("access_token"); uid=j.getJSONObject("user").getString("id"); true }
 } catch(_:Exception){ false }
 private fun startSession():Boolean { val u=uid?:return false; return post("/rest/v1/trf_driver_tracking_sessions", JSONObject().put("driver_id",u).put("driver_name",driver).put("vehicle",vehicle), null) }
 @Suppress("MissingPermission") private fun startGps(){
  val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,15000).setMinUpdateIntervalMillis(10000).setWaitForAccurateLocation(false).build()
  callback=object:LocationCallback(){override fun onLocationResult(r:LocationResult){r.lastLocation?.let{send(it)}}}
  fused.requestLocationUpdates(req,callback!!,mainLooper)
 }
 private fun send(l:Location)=thread {
  if(token==null && !login()) return@thread
  val u=uid?:return@thread
  val now=java.time.Instant.ofEpochMilli(l.time).toString()
  val body=JSONObject().put("driver_id",u).put("driver_name",driver).put("vehicle",vehicle).put("latitude",l.latitude).put("longitude",l.longitude).put("accuracy_m",l.accuracy.toDouble()).put("speed_kmh",if(l.hasSpeed())l.speed*3.6 else JSONObject.NULL).put("heading",if(l.hasBearing())l.bearing.toDouble() else JSONObject.NULL).put("recorded_at",now).put("updated_at",java.time.Instant.now().toString()).put("is_tracking",true)
  if(!post("/rest/v1/trf_driver_locations?on_conflict=driver_id",body,"resolution=merge-duplicates")){ token=null; if(login()) post("/rest/v1/trf_driver_locations?on_conflict=driver_id",body,"resolution=merge-duplicates") }
  val hist=JSONObject(body.toString()); hist.remove("driver_name"); hist.remove("is_tracking"); hist.remove("updated_at"); post("/rest/v1/trf_driver_location_history",hist,null)
 }
 private fun post(path:String,body:JSONObject,prefer:String?):Boolean=try { val c=conn(path,"POST",true); c.setRequestProperty("Content-Type","application/json"); prefer?.let{c.setRequestProperty("Prefer",it)}; c.outputStream.use{it.write(body.toString().toByteArray())}; c.responseCode in 200..299 } catch(_:Exception){false}
 private fun conn(path:String,method:String,auth:Boolean):HttpURLConnection { val c=URL(Config.SUPABASE_URL+path).openConnection() as HttpURLConnection; c.requestMethod=method; c.doOutput=method!="GET"; c.connectTimeout=10000;c.readTimeout=10000;c.setRequestProperty("apikey",Config.SUPABASE_KEY); if(auth) token?.let{c.setRequestProperty("Authorization","Bearer $it")}; return c }
 override fun onDestroy(){ callback?.let{fused.removeLocationUpdates(it)}; thread { if(token!=null){ try { val c=conn("/rest/v1/rpc/trf_stop_my_tracking","POST",true); c.setRequestProperty("Content-Type","application/json"); c.outputStream.use{it.write("{}".toByteArray())}; c.responseCode }catch(_:Exception){} } }; super.onDestroy() }
 private fun channel(){ if(android.os.Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("gps","Seguimiento GPS",NotificationManager.IMPORTANCE_LOW)) }
}
