# Próximo cambio: vista de dueño / administrador

Solicitud del propietario, 2 de octubre de 2026. Pendiente; no implementada en v0.6.

- Luis Ferreira debe tener una experiencia diferenciada como dueño.
- Mapa con la última ubicación de cada camión, actualizada en tiempo real.
- Otras opciones de administración por definir con el propietario.

Diseño propuesto para la próxima versión:
- Acceso por un rol de administración controlado en el servidor y protegido con RLS; el correo o el nombre mostrado no deben autorizar acceso por sí solos.
- Mostrar hora de última actualización para distinguir posiciones recientes de camiones sin conexión.
- Conservar las funciones de chofer cuando el dueño también conduzca.
- Definir y validar permisos de lectura de flota antes de implementar el mapa.
