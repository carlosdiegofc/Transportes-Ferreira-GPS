# Transportes Ferreira GPS — v0.6 Blue Redesign

Reconstruido desde TransportesFerreiraGPS-v0.5.1-Redesign-Fix.zip.

## Funciones conservadas
- Login con correo y contraseña mediante Supabase Auth.
- Chofer asociado al correo: Immer Sampayo, Luis Ferreira y Hugo Silva; otros correos muestran el nombre anterior a @.
- Selección de camión: Ford Cargo 1722, Mercedes-Benz 1618, Leyland y Mercedes-Benz 1630.
- Inicio de sesión de seguimiento, ubicación actual e historial GPS.
- Servicio de ubicación en primer plano y finalización mediante la función existente de Supabase.
- Logo TR Ferreira original y diseño azul/azul marino.

## Compilar
Requisitos: JDK 17, Android SDK 35 y acceso a Internet para descargar dependencias.

Windows: `gradlew.bat assembleDebug lintDebug`
Linux/macOS: `sh gradlew assembleDebug lintDebug`

Abrir esta carpeta en Android Studio y seleccionar JDK 17. Android Studio puede crear local.properties con la ruta local del SDK. No subir ese archivo al repositorio.
El APK de prueba se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Subir a GitHub
Descomprimir el ZIP y subir el CONTENIDO de TransportesFerreiraGPS a la raíz del repositorio, incluyendo .github, gradle, gradlew y gradlew.bat. No subir solamente el ZIP si se quiere compilar con Actions.
El flujo Android APK compila y ejecuta lint en cada push; el APK queda como artefacto descargable. Es un APK debug. Para distribución release se necesita la firma del propietario.

## Supabase existente
Config.kt conserva la URL y clave publicable de la versión proporcionada. No contiene una clave service_role.
La app espera estas tablas y función ya existentes:
- trf_driver_tracking_sessions
- trf_driver_locations (upsert por driver_id)
- trf_driver_location_history
- RPC trf_stop_my_tracking
No se ejecutaron migraciones ni se modificaron las políticas de la base.

## Cambios v0.6
- Versión 0.6.0 (código 6).
- Tema oscuro fijo azul marino, acento azul, botones sin tintes automáticos y lista de camiones con texto claro.
- Ajuste de márgenes para las barras del sistema en Android 15.
- Solicitud conjunta de ubicación precisa/aproximada y continuación del inicio tras conceder permiso.
- Estado del viaje conservado en la interfaz mientras vive el servicio; bloqueo de inicio duplicado y de cierre de sesión durante seguimiento.
- Gradle Wrapper 8.9, JDK/Kotlin 17, configuración de GitHub Actions y exclusiones de archivos locales.
- Copias de seguridad de la app desactivadas para excluir las preferencias de sesión.

## Límites y prueba en teléfono
La compilación no acredita el funcionamiento real de GPS o las políticas del servidor. Probar con una cuenta autorizada: login, camión, inicio, bloqueo de pantalla, recepción en panel, finalización y cierre de sesión.
Se conserva el almacenamiento de credenciales de la base para Recordar mi sesión; una siguiente versión debería usar tokens renovables protegidos con Android Keystore.
Se conserva la finalización remota de la base desde onDestroy, que es de mejor esfuerzo: Android puede matar el proceso sin invocarla y una pérdida de red puede impedir la RPC. No hay cola offline persistente.
El servicio se inicia desde la pantalla visible y muestra una notificación. No se incorporó un flujo nuevo de permiso “Permitir siempre”.
El logo se conserva exactamente como venía en el ZIP.
