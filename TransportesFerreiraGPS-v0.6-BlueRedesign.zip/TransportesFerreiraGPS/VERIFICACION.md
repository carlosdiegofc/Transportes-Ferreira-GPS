# Verificación v0.6

Fecha: 2026-10-02.
Base: TransportesFerreiraGPS-v0.5.1-Redesign-Fix.zip.

- assembleDebug: correcto; APK generado.
- lintDebug: correcto; 0 errores y 42 advertencias (principalmente textos sin recursos de traducción, recursos/tema y versiones de dependencias).
- Paquete: uy.transportesferreira.gps; versión 0.6.0; versionCode 6.
- Android mínimo: API 26; target/compile: API 35.
- Compilación local: Windows, JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.1.0.
- No se probó en teléfono/emulador ni se ejecutó un viaje contra Supabase. Requiere prueba funcional con cuenta autorizada.
- El APK adjunto usa firma de depuración, no la firma de distribución del propietario.

Consultar README.md para los límites heredados del servicio y las instrucciones de GitHub.
