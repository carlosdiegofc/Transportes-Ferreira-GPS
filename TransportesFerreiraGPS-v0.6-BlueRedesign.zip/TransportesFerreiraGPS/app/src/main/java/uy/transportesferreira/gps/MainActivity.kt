package uy.transportesferreira.gps

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity: AppCompatActivity() {
 private val permissions=10
 private lateinit var email:EditText; private lateinit var pass:EditText; private lateinit var remember:CheckBox
 private lateinit var loginPanel:View; private lateinit var tripPanel:View; private lateinit var driverName:TextView; private lateinit var vehicle:Spinner; private lateinit var status:TextView
 private lateinit var start:Button; private lateinit var stop:Button
 private val prefs by lazy{getSharedPreferences("gps",MODE_PRIVATE)}
 private val trucks=arrayOf("Seleccionar camión…","Ford Cargo 1722","Mercedes-Benz 1618","Leyland","Mercedes-Benz 1630")
 private val drivers=mapOf("immer@trferreira.com" to "Immer Sampayo","luis@trferreira.com" to "Luis Ferreira","hugo@trferreira.com" to "Hugo Silva")

 private val receiver=object:BroadcastReceiver(){ override fun onReceive(c:Context?,i:Intent?){ when(i?.action){
  GpsService.ACTION_STARTED->{ vehicle.isEnabled=false; status.text="VIAJE ACTIVO · GPS conectado"; start.isEnabled=false; start.alpha=0.45f; stop.isEnabled=true; stop.alpha=1f }
  GpsService.ACTION_ERROR->{ vehicle.isEnabled=true; status.text="No se pudo iniciar: ${i.getStringExtra("message")?:"error de conexión"}"; start.isEnabled=true; start.alpha=1f; stop.isEnabled=false; stop.alpha=0.45f }
 } } }

 override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_main); androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { view, insets -> val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()); view.setPadding(bars.left, bars.top, bars.right, bars.bottom); insets }
  email=findViewById(R.id.email); pass=findViewById(R.id.password); remember=findViewById(R.id.remember); loginPanel=findViewById(R.id.loginPanel); tripPanel=findViewById(R.id.tripPanel); driverName=findViewById(R.id.driverName); vehicle=findViewById(R.id.vehicle); status=findViewById(R.id.status); start=findViewById(R.id.start); stop=findViewById(R.id.stop)
  vehicle.adapter=ArrayAdapter<String>(this, R.layout.spinner_vehicle, trucks).apply {
   setDropDownViewResource(R.layout.spinner_vehicle)
  }
  email.setText(prefs.getString("email","")); remember.isChecked=prefs.getBoolean("remember",false)
  findViewById<Button>(R.id.login).setOnClickListener{doLogin()}
  start.setOnClickListener{startTrip()}
  stop.setOnClickListener{stopService(Intent(this,GpsService::class.java)); vehicle.isEnabled=true; status.text="Viaje finalizado · GPS detenido"; start.isEnabled=true; start.alpha=1f; stop.isEnabled=false; stop.alpha=0.45f}
  findViewById<Button>(R.id.logout).setOnClickListener{ if(GpsService.running || GpsService.connecting){toast("Finalizá el viaje antes de cerrar sesión");return@setOnClickListener}; prefs.edit().remove("password").putBoolean("remember",false).apply(); pass.setText(""); showLogin() }
  if(prefs.getBoolean("remember",false)){ pass.setText(prefs.getString("password","")); if(pass.text.isNotBlank()) doLogin() }
 }
 override fun onStart(){super.onStart(); val f=IntentFilter().apply{addAction(GpsService.ACTION_STARTED);addAction(GpsService.ACTION_ERROR)}; ContextCompat.registerReceiver(this,receiver,f,ContextCompat.RECEIVER_NOT_EXPORTED)}
 override fun onStop(){try{unregisterReceiver(receiver)}catch(_:Exception){};super.onStop()}
 private fun doLogin(){ val e=email.text.toString().trim().lowercase(); val p=pass.text.toString(); if(e.isBlank()||p.isBlank()){toast("Ingresá correo y contraseña");return}; findViewById<Button>(R.id.login).isEnabled=false
  thread{ val ok=authenticate(e,p); runOnUiThread{findViewById<Button>(R.id.login).isEnabled=true; if(!ok){toast("Correo, contraseña o conexión incorrectos");return@runOnUiThread}; val d=drivers[e]?:e.substringBefore("@").replaceFirstChar{it.uppercase()}; if(remember.isChecked) prefs.edit().putString("email",e).putString("password",p).putBoolean("remember",true).apply() else prefs.edit().putString("email",e).remove("password").putBoolean("remember",false).apply(); driverName.text=d; showTrip() } }
 }
 private fun authenticate(e:String,p:String):Boolean=try{ val c=URL(Config.SUPABASE_URL+"/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection; c.requestMethod="POST";c.doOutput=true;c.connectTimeout=10000;c.readTimeout=10000;c.setRequestProperty("apikey",Config.SUPABASE_KEY);c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(JSONObject().put("email",e).put("password",p).toString().toByteArray())};c.responseCode in 200..299 }catch(_:Exception){false}
 private fun startTrip(){ if(GpsService.running || GpsService.connecting){refreshTripState();return}; if(vehicle.selectedItemPosition==0){toast("Seleccioná el camión");return}; val req=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION); if(Build.VERSION.SDK_INT>=33)req.add(Manifest.permission.POST_NOTIFICATIONS); if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,req.toTypedArray(),permissions);return}; status.text="Conectando con Supabase…";start.isEnabled=false;start.alpha=0.65f
  val i=Intent(this,GpsService::class.java).putExtra("email",email.text.toString().trim()).putExtra("password",pass.text.toString()).putExtra("driver",driverName.text.toString()).putExtra("vehicle",vehicle.selectedItem.toString());ContextCompat.startForegroundService(this,i)
 }
 override fun onRequestPermissionsResult(requestCode:Int, requested:Array<out String>, results:IntArray){ super.onRequestPermissionsResult(requestCode,requested,results); if(requestCode==permissions){ if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED) startTrip() else toast("Para iniciar el viaje, habilitá la ubicación en los ajustes de la aplicación") } }
 private fun showLogin(){loginPanel.visibility=View.VISIBLE;tripPanel.visibility=View.GONE}
 private fun showTrip(){loginPanel.visibility=View.GONE;tripPanel.visibility=View.VISIBLE;status.text="GPS listo para iniciar";start.alpha=1f;stop.alpha=0.45f;refreshTripState()}
 private fun refreshTripState(){ val active=GpsService.running; val busy=GpsService.connecting; start.isEnabled=!active && !busy; start.alpha=if(start.isEnabled)1f else 0.45f; stop.isEnabled=active; stop.alpha=if(active)1f else 0.45f; vehicle.isEnabled=!active && !busy; if(active){status.text="VIAJE ACTIVO · GPS conectado"; val index=trucks.indexOf(GpsService.activeVehicle); if(index>=0)vehicle.setSelection(index)} else if(busy)status.text="Conectando con Supabase…" }
 override fun onResume(){super.onResume();if(::start.isInitialized)refreshTripState()}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}



